# Synthetic Firm Control Room

A premium dark command-center frontend prototype for The Synthetic Firm (TSF) — an autonomous AI agency with five AI agents working like a startup team.

## Features

- **Bird's-eye office map** — Top-down view of all agent rooms with interactive elements
- **5 AI Agents** — Atlas (CEO), Scout (Research), Forge (Builder), Pulse (Growth), Sentinel (Security)
- **Real-time event simulation** — Mock TSF event stream drives all UI changes
- **Approval inbox** — Review and approve/deny external actions with risk assessment
- **Budget tracking** — Visual budget meter with per-agent breakdown and warning thresholds
- **Runtime controls** — Pause, resume, and kill the runtime simulation
- **Workday clock** — Simulated 09:00-17:00 CET workday with phase indicators
- **Meeting system** — Agents physically move to the meeting room during meetings
- **Event timeline** — Live feed of all TSF runtime events
- **Daily reports** — End-of-day summary with efficiency metrics

## Tech Stack

- Vite — Build tool
- React 19 + TypeScript — UI framework
- Tailwind CSS — Styling
- Framer Motion — Animations
- Zustand — State management
- Lucide React — Icons

## Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

The app will be available at `http://localhost:5173`.

## Project Structure

```
src/
  App.tsx                    — Main app component
  main.tsx                   — Entry point
  App.css                    — App-specific styles
  index.css                  — Global styles + Tailwind
  types/
    tsf.ts                   — All TypeScript types
  mocks/
    tsf-events.ts            — Mock event stream generator
    tsf-state.ts             — Initial state data
  store/
    useTsfStore.ts           — Zustand store
  components/
    office/
      OfficeMap.tsx          — Main SVG office map
      OfficeRoom.tsx         — Individual room component
      AgentAvatar.tsx        — Agent avatar with animations
      ActivityLine.tsx       — Meeting connection lines
    panels/
      RuntimeHeader.tsx      — Top bar with clock + controls
      FounderControlPanel.tsx — Right sidebar with tabs
      AgentInspector.tsx     — Agent details panel
      TaskBoard.tsx          — Kanban task board
      ApprovalInbox.tsx      — Approval request cards
      BudgetPanel.tsx        — Budget visualization
      DailyReportPanel.tsx   — Daily report view
      EventTimeline.tsx      — Event log feed
      ReportModal.tsx        — End-of-day modal overlay
    ui/
      GlassPanel.tsx         — Glassmorphism panel wrapper
      StatusPill.tsx         — Status indicator badge
      RiskBadge.tsx          — Risk level badge
  utils/
    eventReducer.ts          — Event processing logic
    workday.ts               — Workday clock utilities
    formatters.ts            — Text/currency/format helpers
docs/
  TSF_FRONTEND_INTEGRATION.md — Backend integration guide
```

## How It Works

1. **Event Simulation** — A mock event stream generates TSF events every few seconds (task created, approval requested, meeting started, etc.)
2. **State Updates** — Events are processed through a reducer that updates the Zustand store
3. **UI Reacts** — Components subscribe to store changes and animate accordingly
4. **User Interaction** — You can click agents/rooms, approve/deny requests, and control the runtime

## Controls

- **Pause/Resume/Kill** — Top-right runtime controls
- **Click agents** — Inspect agent details in the right panel
- **Click rooms** — Focus on specific office areas
- **Approve/Deny** — Action approval requests in the Approvals tab
- **Tabs** — Switch between Agents, Tasks, Approvals, Budget, Reports, Event Log

## Integration

See `docs/TSF_FRONTEND_INTEGRATION.md` for details on connecting this frontend to a real TSF backend.

## Notes

- This is a frontend prototype — no backend, no real AI calls, no external APIs
- Desktop is the primary target; mobile layout is scrollable
- The event simulation clearly demonstrates all TSF runtime behaviors
- All components are fully implemented with no placeholders or TODOs
