# TSF Frontend Integration Guide

## Overview

This document describes how the Synthetic Firm Control Room frontend prototype integrates with the TSF (The Synthetic Firm) backend system. The frontend is designed as a standalone prototype that can be easily connected to real TSF APIs later.

## Mock Architecture

The prototype uses a **mock event stream** (`src/mocks/tsf-events.ts`) to simulate TSF runtime behavior. All state is managed client-side via **Zustand** (`src/store/useTsfStore.ts`). The frontend does not claim to be the source of truth — it is a view layer that will later consume real TSF events.

## Files to Replace for Real Integration

### 1. Event Stream (`src/mocks/tsf-events.ts`)

**Current**: Generates synthetic events on a timer (task created, approval requested, meeting started, etc.)

**Replace with**: A WebSocket connection or Server-Sent Events (SSE) stream from the TSF backend.

**Expected interface**:
```typescript
// WebSocket URL: wss://api.tsf.example.com/v1/events
// or SSE endpoint: https://api.tsf.example.com/v1/events/stream

// Event format (JSON):
{
  "type": "task.created | task.assigned | task.started | task.blocked | ...",
  "timestamp": "2024-01-15T09:30:00Z",
  "agent_id": "atlas | scout | forge | pulse | sentinel",
  "payload": { /* event-specific data */ }
}
```

### 2. Initial State (`src/mocks/tsf-state.ts`)

**Current**: Hardcoded initial agent positions, default budget, office room layout.

**Replace with**: A `/api/v1/state` or `/api/v1/bootstrap` endpoint that returns the current TSF state snapshot on page load.

### 3. Store Actions (`src/store/useTsfStore.ts`)

**Current**: Actions modify local Zustand state only.

**Replace with**: Actions should dispatch to the TSF API and update local state based on API responses.

Key actions and their future API mappings:

| Action | Current | Future API |
|--------|---------|------------|
| `approveRequest(id)` | Updates local state | `POST /api/v1/approvals/{id}/approve` |
| `denyRequest(id)` | Updates local state | `POST /api/v1/approvals/{id}/deny` |
| `pauseRuntime()` | Updates local state | `POST /api/v1/runtime/pause` |
| `resumeRuntime()` | Updates local state | `POST /api/v1/runtime/resume` |
| `killRuntime()` | Updates local state | `POST /api/v1/runtime/kill` |

## Event Types

The frontend expects these event types from the TSF event stream:

```typescript
type EventType =
  | 'task.created'
  | 'task.assigned'
  | 'task.started'
  | 'task.blocked'
  | 'task.review_required'
  | 'task.completed'
  | 'approval.requested'
  | 'approval.approved'
  | 'approval.denied'
  | 'message.sent'
  | 'meeting.started'
  | 'meeting.ended'
  | 'budget.warning'
  | 'budget.exceeded'
  | 'runtime.paused'
  | 'runtime.resumed'
  | 'runtime.killed'
  | 'daily_report.generated'
  | 'agent.state_changed';
```

## Expected Backend Endpoints

### REST API

```
GET  /api/v1/agents              # List all agents with current state
GET  /api/v1/agents/{id}         # Single agent details
GET  /api/v1/tasks               # All tasks
GET  /api/v1/tasks/{id}          # Single task
POST /api/v1/approvals/{id}/approve  # Approve an action
POST /api/v1/approvals/{id}/deny     # Deny an action
GET  /api/v1/budget              # Current budget status
GET  /api/v1/reports/daily       # Daily report
POST /api/v1/runtime/pause       # Pause runtime
POST /api/v1/runtime/resume      # Resume runtime
POST /api/v1/runtime/kill        # Kill runtime
GET  /api/v1/timeline            # Event timeline
```

### WebSocket / SSE

```
WS   /api/v1/events/stream       # Real-time event stream
```

## Approval Flow

The approval system works as follows:

1. **Agent requests external action** → `approval.requested` event emitted
2. **Sentinel reviews** → Risk level and summary attached to the approval
3. **Founder (user) reviews** → Frontend displays approval card with details
4. **Founder approves/denies** → Frontend calls API + updates local state
5. **TSF executes or cancels** → Result reflected in subsequent events

## Runtime State Mapping

| Frontend State | TSF Runtime State | Behavior |
|----------------|-------------------|----------|
| `active` | `RUNNING` | Events flow, agents work, clock advances |
| `paused` | `PAUSED` | Event stream paused, agents idle, clock frozen |
| `killed` | `TERMINATED` | All operations stopped, UI shows lockdown |

## Budget System

The budget meter tracks daily spending:

- **Daily limit**: Set per workday (default $1000 in prototype)
- **Warning thresholds**: 50%, 80%, 95%, 100%
- **Per-agent tracking**: Each agent's spending is tracked separately
- **Visual feedback**: Color-coded progress bar (green → amber → red)

Future: Budget will come from `GET /api/v1/budget` and be updated via budget events.

## Frontend Is Not Source of Truth

This frontend prototype:
- ✅ Displays TSF state received from the backend
- ✅ Allows user interactions (approve/deny/pause/resume/kill)
- ✅ Dispatches actions to the backend
- ✅ Updates UI optimistically based on API responses
- ✅ Reconciles state when backend events arrive

It does NOT:
- ❌ Store persistent state
- ❌ Make decisions about agent behavior
- ❌ Calculate budgets independently
- ❌ Act as the system of record

## Integration Steps for Codex

1. **Replace event stream**: Swap `createEventStream()` with WebSocket/SSE connection
2. **Replace initial state**: Fetch from `/api/v1/state` on mount
3. **Add API client**: Create `src/api/tsf-client.ts` with typed HTTP methods
4. **Wire store actions**: Replace local mutations with API calls
5. **Add auth**: Include auth tokens in API requests
6. **Add error handling**: Handle network errors, reconnection logic
7. **Remove mock files**: Delete `src/mocks/` when no longer needed

## TypeScript Types

All types are defined in `src/types/tsf.ts`. These should align with the TSF backend API schema. The types are comprehensive and cover:

- `Agent` — Agent identity, state, position
- `Task` — Task lifecycle, assignment, costs
- `Approval` — Approval requests with Sentinel review
- `Meeting` — Meeting sessions with participants
- `Budget` — Daily budget tracking
- `DailyReport` — End-of-day summary
- `TimelineEvent` — Generic event log entry

## State Management

The Zustand store (`src/store/useTsfStore.ts`) provides:
- Centralized state for all TSF entities
- Actions for user interactions
- Event processing via reducer pattern
- Clock advancement logic

When integrating with the real backend:
- Keep Zustand for UI state (selected tabs, modals)
- Move TSF entity state to API-driven updates
- Keep the reducer pattern but have it process real events
