import { useEffect, useRef, Suspense } from 'react';
import { useTsfStore } from '@/store/useTsfStore';
import { Scene3D } from '@/components/scene/Scene';
import { RuntimeHeader } from '@/components/hud/RuntimeHeader';
import { FounderControlPanel } from '@/components/hud/FounderControlPanel';
import { ReportModal } from '@/components/hud/ReportModal';
import './App.css';

// Loading fallback for 3D scene
function SceneLoader() {
  return (
    <div className="flex h-full w-full items-center justify-center bg-[#05080F]">
      <div className="text-center">
        <div className="mx-auto mb-4 h-8 w-8 animate-spin rounded-full border-2 border-[#06B6D4] border-t-transparent" />
        <p className="text-xs tracking-[0.2em] text-[#475569]">INITIALIZING 3D SCENE</p>
      </div>
    </div>
  );
}

function App() {
  const runtimeState = useTsfStore((s) => s.runtimeState);
  const startEventSimulation = useTsfStore((s) => s.startEventSimulation);
  const stopEventSimulation = useTsfStore((s) => s.stopEventSimulation);
  const advanceClock = useTsfStore((s) => s.advanceClock);

  const clockIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Start event simulation
  useEffect(() => {
    startEventSimulation();
    return () => stopEventSimulation();
  }, [startEventSimulation, stopEventSimulation]);

  // Clock ticker
  useEffect(() => {
    if (runtimeState === 'active') {
      clockIntervalRef.current = setInterval(() => advanceClock(), 600);
    } else {
      if (clockIntervalRef.current) clearInterval(clockIntervalRef.current);
    }
    return () => {
      if (clockIntervalRef.current) clearInterval(clockIntervalRef.current);
    };
  }, [runtimeState, advanceClock]);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#05080F]">
      {/* 3D Scene — fills the background */}
      <div className="absolute inset-0 z-0">
        <Suspense fallback={<SceneLoader />}>
          <Scene3D />
        </Suspense>
      </div>

      {/* HUD Overlay */}
      <div className="pointer-events-none absolute inset-0 z-10">
        {/* Runtime Header — top bar */}
        <RuntimeHeader />

        {/* Founder Control Panel — right sidebar */}
        <FounderControlPanel />

        {/* Bottom-left corner info */}
        <div className="pointer-events-auto absolute bottom-3 left-3">
          <p className="text-[9px] tracking-[0.15em] text-[#1e293b]">
            TSF CONTROL ROOM v2.0 — THREE.JS RENDERER
          </p>
        </div>
      </div>

      {/* Report Modal */}
      <ReportModal />
    </div>
  );
}

export default App;
