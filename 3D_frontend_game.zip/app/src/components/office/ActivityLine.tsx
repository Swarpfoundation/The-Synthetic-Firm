import { motion } from 'framer-motion';

interface ActivityLineProps {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  color: string;
  isActive: boolean;
}

export function ActivityLine({ x1, y1, x2, y2, color, isActive }: ActivityLineProps) {
  if (!isActive) return null;

  const length = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);

  return (
    <motion.g
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Background line */}
      <line
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        stroke={`${color}30`}
        strokeWidth={2}
        strokeDasharray="8 4"
      />
      {/* Animated flow line */}
      <line
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        stroke={color}
        strokeWidth={2}
        strokeDasharray={`${length * 0.3} ${length * 0.7}`}
        opacity={0.8}
      >
        <animate
          attributeName="stroke-dashoffset"
          from={`-${length}`}
          to="0"
          dur="1.5s"
          repeatCount="indefinite"
        />
      </line>
      {/* End dot */}
      <circle cx={x2} cy={y2} r={4} fill={color} opacity={0.6}>
        <animate attributeName="r" values="3;5;3" dur="1s" repeatCount="indefinite" />
        <animate attributeName="opacity" values="0.4;0.8;0.4" dur="1s" repeatCount="indefinite" />
      </circle>
    </motion.g>
  );
}
