import { motion } from 'framer-motion';
import type { Agent } from '@/types/tsf';
import {
  Crown,
  Search,
  Hammer,
  TrendingUp,
  Shield,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  Crown,
  Search,
  Hammer,
  TrendingUp,
  Shield,
};

interface AgentAvatarProps {
  agent: Agent;
  isSelected: boolean;
  scale: number;
  onClick: () => void;
}

export function AgentAvatar({ agent, isSelected, scale, onClick }: AgentAvatarProps) {
  const IconComponent = iconMap[agent.avatar] || Crown;
  const size = 44 * scale;
  const halfSize = size / 2;

  const isActive = agent.state !== 'idle' && agent.state !== 'paused' && agent.state !== 'blocked';
  const isBlocked = agent.state === 'blocked';
  const isInMeeting = agent.state === 'meeting';

  return (
    <motion.g
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      className="cursor-pointer"
      animate={{
        x: agent.position.x - halfSize,
        y: agent.position.y - halfSize,
      }}
      transition={{
        type: 'spring',
        stiffness: 80,
        damping: 20,
        mass: 0.8,
      }}
      whileHover={{ scale: 1.15 }}
    >
      {/* Status ring (outer glow) */}
      {isActive && (
        <circle
          cx={halfSize}
          cy={halfSize}
          r={halfSize + 4}
          fill="none"
          stroke={agent.color}
          strokeWidth={2}
          strokeDasharray="4 3"
          opacity={0.6}
        >
          <animateTransform
            attributeName="transform"
            type="rotate"
            from={`0 ${halfSize} ${halfSize}`}
            to={`360 ${halfSize} ${halfSize}`}
            dur="8s"
            repeatCount="indefinite"
          />
        </circle>
      )}

      {/* Blocked indicator */}
      {isBlocked && (
        <circle
          cx={halfSize}
          cy={halfSize}
          r={halfSize + 3}
          fill="none"
          stroke="#EF4444"
          strokeWidth={2}
          strokeDasharray="6 4"
          opacity={0.8}
        >
          <animate attributeName="opacity" values="0.4;0.9;0.4" dur="1.5s" repeatCount="indefinite" />
        </circle>
      )}

      {/* Meeting indicator */}
      {isInMeeting && (
        <circle
          cx={halfSize}
          cy={halfSize}
          r={halfSize + 6}
          fill="none"
          stroke="#F9FAFB"
          strokeWidth={1.5}
          opacity={0.5}
        >
          <animate attributeName="r" values={`${halfSize + 4};${halfSize + 8};${halfSize + 4}`} dur="2s" repeatCount="indefinite" />
          <animate attributeName="opacity" values="0.3;0.6;0.3" dur="2s" repeatCount="indefinite" />
        </circle>
      )}

      {/* Avatar background */}
      <circle
        cx={halfSize}
        cy={halfSize}
        r={halfSize}
        fill="#1F2937"
        stroke={isSelected ? agent.color : agent.color + '80'}
        strokeWidth={isSelected ? 3 : 2}
        style={{
          filter: isSelected
            ? `drop-shadow(0 0 10px ${agent.color}60)`
            : `drop-shadow(0 2px 4px rgba(0,0,0,0.5))`,
          transition: 'all 0.2s ease',
        }}
      />

      {/* Active pulse glow */}
      {isActive && (
        <circle
          cx={halfSize}
          cy={halfSize}
          r={halfSize}
          fill={agent.color}
          opacity={0.1}
        >
          <animate attributeName="opacity" values="0.05;0.2;0.05" dur="2s" repeatCount="indefinite" />
        </circle>
      )}

      {/* Icon */}
      <foreignObject x={4} y={4} width={size - 8} height={size - 8}>
        <div className="flex h-full w-full items-center justify-center">
          <IconComponent
            className={cn('text-[#F9FAFB]', isActive && 'drop-shadow-lg')}
            style={{
              width: size * 0.45,
              height: size * 0.45,
              color: isActive ? agent.color : '#F9FAFB',
              filter: isActive ? `drop-shadow(0 0 4px ${agent.color}80)` : 'none',
            } as React.CSSProperties}
          />
        </div>
      </foreignObject>

      {/* Name label below avatar */}
      <text
        x={halfSize}
        y={size + 14}
        fill={isSelected ? agent.color : '#9CA3AF'}
        fontSize={10 * scale}
        fontWeight={600}
        fontFamily="Inter, sans-serif"
        textAnchor="middle"
        letterSpacing={0.5}
      >
        {agent.name}
      </text>

      {/* State label */}
      <text
        x={halfSize}
        y={size + 26}
        fill="#6B7280"
        fontSize={8 * scale}
        fontWeight={400}
        fontFamily="Inter, sans-serif"
        textAnchor="middle"
        letterSpacing={0.5}
      >
        {agent.state.replace(/_/g, ' ')}
      </text>

      {/* Selection ring */}
      {isSelected && (
        <circle
          cx={halfSize}
          cy={halfSize}
          r={halfSize + 2}
          fill="none"
          stroke={agent.color}
          strokeWidth={2}
          strokeDasharray="3 2"
          opacity={0.8}
        >
          <animateTransform
            attributeName="transform"
            type="rotate"
            from={`0 ${halfSize} ${halfSize}`}
            to={`360 ${halfSize} ${halfSize}`}
            dur="6s"
            repeatCount="indefinite"
          />
        </circle>
      )}
    </motion.g>
  );
}
