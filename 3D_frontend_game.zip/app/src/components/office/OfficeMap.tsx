import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTsfStore } from '@/store/useTsfStore';
import { officeRooms } from '@/mocks/tsf-state';
import { OfficeRoom } from './OfficeRoom';
import { AgentAvatar } from './AgentAvatar';
import { ActivityLine } from './ActivityLine';

const MAP_WIDTH = 1000;
const MAP_HEIGHT = 800;

export function OfficeMap() {
  const agents = useTsfStore((s) => s.agents);
  const selectedAgentId = useTsfStore((s) => s.selectedAgentId);
  const selectedRoomId = useTsfStore((s) => s.selectedRoomId);
  const activeMeeting = useTsfStore((s) => s.activeMeeting);
  const runtimeState = useTsfStore((s) => s.runtimeState);
  const selectAgent = useTsfStore((s) => s.selectAgent);
  const selectRoom = useTsfStore((s) => s.selectRoom);

  const meetingCenter = useMemo(() => ({ x: 500, y: 450 }), []);

  const isMeetingActive = !!activeMeeting?.isActive;

  return (
    <div className="relative flex-1 overflow-hidden bg-[#0A0E17]">
      {/* Pause overlay */}
      <AnimatePresence>
        {runtimeState === 'paused' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="pointer-events-none absolute inset-0 z-20"
            style={{
              background: 'rgba(10, 14, 23, 0.7)',
              backdropFilter: 'brightness(0.5) grayscale(0.6)',
            }}
          >
            <div className="flex h-full items-center justify-center">
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0.8 }}
                  animate={{ scale: 1 }}
                  className="text-4xl font-bold tracking-[0.3em] text-[#F59E0B]"
                >
                  PAUSED
                </motion.div>
                <p className="mt-2 text-sm tracking-wider text-[#9CA3AF]">
                  Event simulation halted
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Kill overlay */}
      <AnimatePresence>
        {runtimeState === 'killed' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="pointer-events-none absolute inset-0 z-20"
            style={{
              background: 'rgba(239, 68, 68, 0.15)',
              backdropFilter: 'brightness(0.4) grayscale(0.8)',
            }}
          >
            <div className="flex h-full items-center justify-center">
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0.8 }}
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="text-4xl font-bold tracking-[0.3em] text-[#EF4444]"
                >
                  RUNTIME KILLED
                </motion.div>
                <p className="mt-2 text-sm tracking-wider text-[#EF4444]/70">
                  All operations terminated
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* SVG Office Map */}
      <svg
        viewBox={`0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`}
        preserveAspectRatio="xMidYMid meet"
        className="h-full w-full"
        style={{
          backgroundImage: `
            linear-gradient(#111827 1px, transparent 1px),
            linear-gradient(90deg, #111827 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
        }}
      >
        {/* Floor corridor lines */}
        <g opacity={0.3}>
          {/* Horizontal corridors */}
          <line x1={300} y1={150} x2={350} y2={150} stroke="#374151" strokeWidth={20} />
          <line x1={650} y1={125} x2={700} y2={150} stroke="#374151" strokeWidth={20} />
          <line x1={250} y1={475} x2={300} y2={450} stroke="#374151" strokeWidth={20} />
          <line x1={300} y1={300} x2={300} y2={350} stroke="#374151" strokeWidth={20} />
          <line x1={700} y1={300} x2={700} y2={350} stroke="#374151" strokeWidth={20} />
          <line x1={300} y1={650} x2={350} y2={650} stroke="#374151" strokeWidth={20} />
          <line x1={700} y1={650} x2={750} y2={650} stroke="#374151" strokeWidth={20} />
          <line x1={0} y1={600} x2={250} y2={600} stroke="#374151" strokeWidth={20} />
        </g>

        {/* Activity lines from agents to meeting room */}
        <AnimatePresence>
          {isMeetingActive &&
            activeMeeting?.participantIds.map((agentId) => {
              const agent = agents[agentId];
              if (!agent) return null;
              return (
                <ActivityLine
                  key={agentId}
                  x1={agent.position.x}
                  y1={agent.position.y}
                  x2={meetingCenter.x}
                  y2={meetingCenter.y}
                  color={agent.color}
                  isActive={isMeetingActive}
                />
              );
            })}
        </AnimatePresence>

        {/* Rooms */}
        {officeRooms.map((room) => (
          <OfficeRoom
            key={room.id}
            room={room}
            isSelected={selectedRoomId === room.id}
            isMeetingActive={isMeetingActive}
            onClick={() => selectRoom(selectedRoomId === room.id ? null : room.id)}
            scale={1}
          />
        ))}

        {/* Agent avatars */}
        {Object.values(agents).map((agent) => (
          <AgentAvatar
            key={agent.id}
            agent={agent}
            isSelected={selectedAgentId === agent.id}
            scale={1}
            onClick={() => selectAgent(selectedAgentId === agent.id ? null : agent.id)}
          />
        ))}

        {/* Map border */}
        <rect
          x={0}
          y={0}
          width={MAP_WIDTH}
          height={MAP_HEIGHT}
          fill="none"
          stroke="#374151"
          strokeWidth={2}
        />
      </svg>

      {/* Corner label */}
      <div className="pointer-events-none absolute bottom-3 left-3 text-[10px] tracking-[0.2em] text-[#374151]">
        TSF OFFICE MAP — VIRTUAL FLOOR PLAN
      </div>
    </div>
  );
}
