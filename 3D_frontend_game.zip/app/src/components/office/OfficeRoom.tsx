import { motion } from 'framer-motion';
import type { OfficeRoom as OfficeRoomType } from '@/types/tsf';


interface OfficeRoomProps {
  room: OfficeRoomType;
  isSelected: boolean;
  isMeetingActive: boolean;
  onClick: () => void;
  scale: number;
}

export function OfficeRoom({ room, isSelected, isMeetingActive, onClick, scale }: OfficeRoomProps) {
  const isMeetingRoom = room.id === 'meeting-room';

  return (
    <motion.g
      onClick={onClick}
      className="cursor-pointer"
      whileHover={{ scale: 1.01 }}
      transition={{ duration: 0.15 }}
    >
      {/* Room floor */}
      <rect
        x={room.x}
        y={room.y}
        width={room.width}
        height={room.height}
        rx={4}
        fill={isMeetingActive && isMeetingRoom ? `${room.color}15` : '#111827'}
        fillOpacity={0.7}
        stroke={isSelected ? room.color : isMeetingActive && isMeetingRoom ? room.color : '#374151'}
        strokeWidth={isSelected ? 2.5 : 1.5}
        style={{
          filter: isSelected
            ? `drop-shadow(0 0 12px ${room.color}40)`
            : isMeetingActive && isMeetingRoom
              ? `drop-shadow(0 0 8px ${room.color}30)`
              : 'none',
          transition: 'all 0.2s ease',
        }}
      />

      {/* Room label */}
      <text
        x={room.x + 12}
        y={room.y + 20}
        fill={isSelected ? room.color : '#9CA3AF'}
        fontSize={12 * scale}
        fontWeight={600}
        fontFamily="Inter, sans-serif"
        letterSpacing={1.5}
        style={{ transition: 'fill 0.2s ease' }}
      >
        {room.label}
      </text>

      {/* Grid lines inside room (tech blueprint feel) */}
      <defs>
        <pattern id={`grid-${room.id}`} width={20} height={20} patternUnits="userSpaceOnUse">
          <path d={`M 20 0 L 0 0 0 20`} fill="none" stroke={`${room.color}10`} strokeWidth={0.5} />
        </pattern>
      </defs>
      <rect
        x={room.x + 2}
        y={room.y + 28}
        width={room.width - 4}
        height={room.height - 30}
        rx={2}
        fill={`url(#grid-${room.id})`}
      />

      {/* Meeting room table */}
      {isMeetingRoom && (
        <g>
          <rect
            x={room.x + room.width / 2 - 80}
            y={room.y + room.height / 2 - 40}
            width={160}
            height={80}
            rx={12}
            fill="#1F2937"
            stroke="#374151"
            strokeWidth={1}
          />
          {/* Chairs */}
          {[0, 1, 2, 3, 4].map((i) => (
            <circle
              key={i}
              cx={room.x + room.width / 2 - 60 + i * 30}
              cy={room.y + room.height / 2 + 55}
              r={8}
              fill="#374151"
              stroke="#4B5563"
              strokeWidth={0.5}
            />
          ))}
          {[0, 1, 2].map((i) => (
            <circle
              key={`top-${i}`}
              cx={room.x + room.width / 2 - 40 + i * 40}
              cy={room.y + room.height / 2 - 55}
              r={8}
              fill="#374151"
              stroke="#4B5563"
              strokeWidth={0.5}
            />
          ))}
        </g>
      )}

      {/* Server racks in server room */}
      {room.id === 'server-core' && (
        <g>
          {[0, 1, 2, 3].map((i) => (
            <g key={i}>
              <rect
                x={room.x + 30 + i * 70}
                y={room.y + 40}
                width={50}
                height={90}
                rx={2}
                fill="#0A0E17"
                stroke="#374151"
                strokeWidth={1}
              />
              {/* LED lights */}
              {[0, 1, 2, 3, 4].map((j) => (
                <circle
                  key={j}
                  cx={room.x + 42 + i * 70}
                  cy={room.y + 55 + j * 14}
                  r={2}
                  fill={j % 2 === 0 ? '#06B6D4' : '#8B5CF6'}
                  opacity={0.6 + Math.random() * 0.4}
                >
                  <animate
                    attributeName="opacity"
                    values="0.4;1;0.4"
                    dur={`${1 + Math.random() * 2}s`}
                    repeatCount="indefinite"
                  />
                </circle>
              ))}
              {[0, 1, 2, 3, 4].map((j) => (
                <circle
                  key={`r-${j}`}
                  cx={room.x + 58 + i * 70}
                  cy={room.y + 55 + j * 14}
                  r={2}
                  fill={j % 3 === 0 ? '#10B981' : '#06B6D4'}
                  opacity={0.5}
                >
                  <animate
                    attributeName="opacity"
                    values="0.3;0.9;0.3"
                    dur={`${1.5 + Math.random() * 2}s`}
                    repeatCount="indefinite"
                  />
                </circle>
              ))}
            </g>
          ))}
        </g>
      )}

      {/* Task board in approval chamber */}
      {room.id === 'approval-chamber' && (
        <g>
          <rect
            x={room.x + 20}
            y={room.y + 30}
            width={room.width - 40}
            height={room.height - 50}
            rx={4}
            fill="#0A0E17"
            stroke="#374151"
            strokeWidth={1}
          />
          {/* Kanban columns */}
          <text x={room.x + 35} y={room.y + 50} fill="#9CA3AF" fontSize={8} fontWeight={600}>
            PENDING
          </text>
          <text x={room.x + 110} y={room.y + 50} fill="#9CA3AF" fontSize={8} fontWeight={600}>
            ACTIVE
          </text>
          <text x={room.x + 175} y={room.y + 50} fill="#9CA3AF" fontSize={8} fontWeight={600}>
            DONE
          </text>
          {/* Sample cards */}
          <rect x={room.x + 30} y={room.y + 60} width={60} height={20} rx={2} fill="#F59E0B20" stroke="#F59E0B40" strokeWidth={0.5} />
          <rect x={room.x + 30} y={room.y + 88} width={60} height={20} rx={2} fill="#EF444420" stroke="#EF444440" strokeWidth={0.5} />
          <rect x={room.x + 105} y={room.y + 60} width={55} height={20} rx={2} fill="#3B82F620" stroke="#3B82F640" strokeWidth={0.5} />
          <rect x={room.x + 170} y={room.y + 60} width={55} height={20} rx={2} fill="#10B98120" stroke="#10B98140" strokeWidth={0.5} />
          <rect x={room.x + 170} y={room.y + 88} width={55} height={20} rx={2} fill="#10B98120" stroke="#10B98140" strokeWidth={0.5} />
        </g>
      )}
    </motion.g>
  );
}
