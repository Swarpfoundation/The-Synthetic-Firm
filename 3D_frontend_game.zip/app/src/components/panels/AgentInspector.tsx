import { useTsfStore } from '@/store/useTsfStore';
import { GlassPanel } from '@/components/ui/GlassPanel';
import { StatusPill } from '@/components/ui/StatusPill';
import {
  Crown,
  Search,
  Hammer,
  TrendingUp,
  Shield,
  Briefcase,
  AlertCircle,
} from 'lucide-react';

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  Crown,
  Search,
  Hammer,
  TrendingUp,
  Shield,
};

export function AgentInspector() {
  const agents = useTsfStore((s) => s.agents);
  const selectedAgentId = useTsfStore((s) => s.selectedAgentId);
  const selectAgent = useTsfStore((s) => s.selectAgent);
  const tasks = useTsfStore((s) => s.tasks);
  const budget = useTsfStore((s) => s.budget);

  // If an agent is selected, show detailed view
  if (selectedAgentId) {
    const agent = agents[selectedAgentId];
    const agentTasks = tasks.filter((t) => t.assignedTo === agent.id);
    const activeTask = agentTasks.find((t) => t.status === 'in_progress');
    const completedTasks = agentTasks.filter((t) => t.status === 'completed');
    const agentBudget = budget.perAgentUsage[agent.id];
    const IconComponent = iconMap[agent.avatar] || Crown;

    return (
      <div className="space-y-3">
        {/* Back button */}
        <button
          onClick={() => selectAgent(null)}
          className="text-[10px] uppercase tracking-wider text-[#6B7280] transition-colors hover:text-[#F9FAFB]"
        >
          ← Back to all agents
        </button>

        {/* Agent header */}
        <GlassPanel className="border-l-4" borderColor={agent.color}>
          <div className="flex items-center gap-3">
            <div
              className="flex h-12 w-12 items-center justify-center rounded-full"
              style={{ backgroundColor: `${agent.color}20`, border: `2px solid ${agent.color}60` }}
            >
              <IconComponent className="h-6 w-6" style={{ color: agent.color }} />
            </div>
            <div>
              <h3 className="text-base font-semibold text-[#F9FAFB]">{agent.name}</h3>
              <p className="text-[11px] text-[#9CA3AF]">{agent.role}</p>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <StatusPill status={agent.state} />
          </div>

          {activeTask && (
            <div className="mt-3 rounded bg-[#0A0E17] p-2.5">
              <div className="flex items-center gap-1.5">
                <Briefcase className="h-3 w-3 text-[#06B6D4]" />
                <span className="text-[10px] uppercase tracking-wider text-[#6B7280]">Active Task</span>
              </div>
              <p className="mt-1 text-xs text-[#F9FAFB]">{activeTask.title}</p>
            </div>
          )}

          {agent.state === 'blocked' && (
            <div className="mt-3 flex items-center gap-1.5 rounded bg-[#EF4444]/10 p-2">
              <AlertCircle className="h-3 w-3 text-[#EF4444]" />
              <span className="text-[10px] text-[#EF4444]">Agent is blocked — requires intervention</span>
            </div>
          )}
        </GlassPanel>

        {/* Stats */}
        <GlassPanel>
          <h4 className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
            Statistics
          </h4>
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded bg-[#0A0E17] p-2.5">
              <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Tasks Completed</p>
              <p className="mt-1 font-mono text-lg font-semibold text-[#10B981]">{completedTasks.length}</p>
            </div>
            <div className="rounded bg-[#0A0E17] p-2.5">
              <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Active Tasks</p>
              <p className="mt-1 font-mono text-lg font-semibold text-[#3B82F6]">
                {agentTasks.filter((t) => t.status === 'in_progress').length}
              </p>
            </div>
            <div className="rounded bg-[#0A0E17] p-2.5">
              <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Budget Used</p>
              <p className="mt-1 font-mono text-lg font-semibold" style={{ color: agentBudget > 200 ? '#F59E0B' : '#F9FAFB' }}>
                ${agentBudget}
              </p>
            </div>
            <div className="rounded bg-[#0A0E17] p-2.5">
              <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Total Tasks</p>
              <p className="mt-1 font-mono text-lg font-semibold text-[#F9FAFB]">{agentTasks.length}</p>
            </div>
          </div>
        </GlassPanel>

        {/* Task history */}
        {agentTasks.length > 0 && (
          <GlassPanel>
            <h4 className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
              Task History
            </h4>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {agentTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between rounded bg-[#0A0E17] px-2.5 py-2"
                >
                  <span className="truncate text-[11px] text-[#F9FAFB]">{task.title}</span>
                  <StatusPill status={task.status} size="sm" />
                </div>
              ))}
            </div>
          </GlassPanel>
        )}
      </div>
    );
  }

  // Show all agents overview
  return (
    <div className="space-y-2">
      <h3 className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
        All Agents
      </h3>
      {Object.values(agents).map((agent) => {
        const IconComponent = iconMap[agent.avatar] || Crown;
        const isSelected = selectedAgentId === agent.id;
        const agentTaskCount = tasks.filter((t) => t.assignedTo === agent.id).length;

        return (
          <button
            key={agent.id}
            onClick={() => selectAgent(agent.id)}
            className="w-full text-left transition-all"
          >
            <GlassPanel
              className={`hover:border-[#374151] ${isSelected ? 'border-[#06B6D4]' : ''}`}
              borderColor={isSelected ? agent.color : undefined}
            >
              <div className="flex items-center gap-2.5">
                <div
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full"
                  style={{
                    backgroundColor: `${agent.color}15`,
                    border: `1.5px solid ${agent.color}50`,
                  }}
                >
                  <IconComponent className="h-4 w-4" style={{ color: agent.color }} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-[#F9FAFB]">{agent.name}</span>
                    <StatusPill status={agent.state} size="sm" />
                  </div>
                  <p className="truncate text-[10px] text-[#6B7280]">{agent.role}</p>
                  {agentTaskCount > 0 && (
                    <p className="text-[9px] text-[#6B7280]">{agentTaskCount} tasks assigned</p>
                  )}
                </div>
              </div>
            </GlassPanel>
          </button>
        );
      })}
    </div>
  );
}
