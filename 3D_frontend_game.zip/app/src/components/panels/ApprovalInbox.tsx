import { motion, AnimatePresence } from 'framer-motion';
import { useTsfStore } from '@/store/useTsfStore';
import { GlassPanel } from '@/components/ui/GlassPanel';
import { RiskBadge } from '@/components/ui/RiskBadge';
import { StatusPill } from '@/components/ui/StatusPill';
import {
  ShieldAlert,
  CheckCircle,
  XCircle,
  ExternalLink,
  Shield,
} from 'lucide-react';

export function ApprovalInbox() {
  const approvals = useTsfStore((s) => s.approvals);
  const approveRequest = useTsfStore((s) => s.approveRequest);
  const denyRequest = useTsfStore((s) => s.denyRequest);
  const runtimeState = useTsfStore((s) => s.runtimeState);

  const pending = approvals.filter((a) => a.status === 'pending');
  const resolved = approvals.filter((a) => a.status !== 'pending');

  if (approvals.length === 0) {
    return (
      <GlassPanel className="flex flex-col items-center justify-center py-12">
        <ShieldAlert className="h-8 w-8 text-[#374151]" />
        <p className="mt-3 text-xs text-[#6B7280]">No approvals yet</p>
        <p className="mt-1 text-[10px] text-[#4B5563]">External actions will appear here</p>
      </GlassPanel>
    );
  }

  return (
    <div className="space-y-3">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded bg-[#0A0E17] p-2 text-center">
          <p className="font-mono text-lg font-semibold text-[#F59E0B]">{pending.length}</p>
          <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Pending</p>
        </div>
        <div className="rounded bg-[#0A0E17] p-2 text-center">
          <p className="font-mono text-lg font-semibold text-[#10B981]">
            {approvals.filter((a) => a.status === 'approved').length}
          </p>
          <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Approved</p>
        </div>
        <div className="rounded bg-[#0A0E17] p-2 text-center">
          <p className="font-mono text-lg font-semibold text-[#EF4444]">
            {approvals.filter((a) => a.status === 'denied').length}
          </p>
          <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Denied</p>
        </div>
      </div>

      {/* Pending approvals */}
      {pending.length > 0 && (
        <div>
          <h4 className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-[#F59E0B]">
            Pending Approval
          </h4>
          <div className="space-y-2">
            <AnimatePresence>
              {pending.map((approval) => (
                <motion.div
                  key={approval.id}
                  layout
                  initial={{ opacity: 0, y: -20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, x: 50 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                >
                  <GlassPanel
                    className="border-l-4"
                    borderColor={approval.riskLevel === 'critical' ? '#EF4444' : approval.riskLevel === 'high' ? '#F59E0B' : '#374151'}
                  >
                    {/* Header */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-semibold text-[#06B6D4]">
                            {approval.requesterId}
                          </span>
                          {approval.hasExternalEffect && (
                            <span className="flex items-center gap-0.5 rounded bg-[#EF4444]/10 px-1 py-0.5 text-[8px] text-[#EF4444]">
                              <ExternalLink className="h-2 w-2" /> EXTERNAL
                            </span>
                          )}
                        </div>
                        <p className="mt-0.5 text-xs text-[#F9FAFB]">{approval.action}</p>
                      </div>
                      <RiskBadge level={approval.riskLevel} />
                    </div>

                    {/* Description */}
                    <p className="mt-2 text-[10px] leading-relaxed text-[#9CA3AF]">
                      {approval.description}
                    </p>

                    {/* Sentinel review */}
                    <div className="mt-2 flex items-start gap-1.5 rounded bg-[#0A0E17] p-2">
                      <Shield className="mt-0.5 h-3 w-3 shrink-0 text-[#8B5CF6]" />
                      <p className="text-[9px] leading-relaxed text-[#8B5CF6]">
                        {approval.sentinelReview}
                      </p>
                    </div>

                    {/* Actions */}
                    {runtimeState !== 'killed' && (
                      <div className="mt-3 flex gap-2">
                        <button
                          onClick={() => approveRequest(approval.id)}
                          className="flex flex-1 items-center justify-center gap-1.5 rounded bg-[#10B981]/10 py-2 text-[10px] font-semibold uppercase tracking-wider text-[#10B981] transition-all hover:bg-[#10B981]/20"
                        >
                          <CheckCircle className="h-3 w-3" />
                          Approve
                        </button>
                        <button
                          onClick={() => denyRequest(approval.id)}
                          className="flex flex-1 items-center justify-center gap-1.5 rounded bg-[#374151]/50 py-2 text-[10px] font-semibold uppercase tracking-wider text-[#9CA3AF] transition-all hover:bg-[#374151]"
                        >
                          <XCircle className="h-3 w-3" />
                          Deny
                        </button>
                      </div>
                    )}
                  </GlassPanel>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* Resolved approvals */}
      {resolved.length > 0 && (
        <div>
          <h4 className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
            Resolved
          </h4>
          <div className="space-y-1.5 opacity-60">
            {resolved.map((approval) => (
              <GlassPanel key={approval.id} className="py-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-[#9CA3AF]">{approval.requesterId}</span>
                    <span className="truncate text-[11px] text-[#F9FAFB]">{approval.action}</span>
                  </div>
                  <StatusPill status={approval.status} size="sm" />
                </div>
              </GlassPanel>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
