import { motion } from 'framer-motion';
import { useTsfStore } from '@/store/useTsfStore';
import { GlassPanel } from '@/components/ui/GlassPanel';
import { Wallet, AlertTriangle, PiggyBank } from 'lucide-react';

const AGENT_NAMES: Record<string, string> = {
  atlas: 'Atlas',
  scout: 'Scout',
  forge: 'Forge',
  pulse: 'Pulse',
  sentinel: 'Sentinel',
};

const AGENT_COLORS: Record<string, string> = {
  atlas: '#06B6D4',
  scout: '#8B5CF6',
  forge: '#F59E0B',
  pulse: '#10B981',
  sentinel: '#EF4444',
};

export function BudgetPanel() {
  const budget = useTsfStore((s) => s.budget);

  const pct = Math.min((budget.currentUsage / budget.dailyLimit) * 100, 100);
  const remaining = budget.dailyLimit - budget.currentUsage;

  const getThresholdLabel = () => {
    if (pct >= 100) return { text: 'EXHAUSTED', color: '#EF4444' };
    if (pct >= 95) return { text: 'CRITICAL', color: '#EF4444' };
    if (pct >= 80) return { text: 'WARNING', color: '#F59E0B' };
    if (pct >= 50) return { text: 'CAUTION', color: '#F59E0B' };
    return { text: 'HEALTHY', color: '#10B981' };
  };

  const threshold = getThresholdLabel();

  return (
    <div className="space-y-3">
      {/* Main budget meter */}
      <GlassPanel>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wallet className="h-4 w-4 text-[#06B6D4]" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
              Daily Budget
            </span>
          </div>
          <span
            className="rounded px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider"
            style={{
              backgroundColor: `${threshold.color}20`,
              color: threshold.color,
              border: `1px solid ${threshold.color}40`,
            }}
          >
            {threshold.text}
          </span>
        </div>

        <div className="mt-4">
          <div className="flex items-end justify-between">
            <div>
              <p className="font-mono text-2xl font-semibold text-[#F9FAFB]">
                ${budget.currentUsage.toFixed(0)}
              </p>
              <p className="text-[10px] text-[#6B7280]">
                of ${budget.dailyLimit.toFixed(0)} used
              </p>
            </div>
            <div className="text-right">
              <p className="font-mono text-lg font-semibold" style={{ color: remaining < 100 ? '#EF4444' : '#10B981' }}>
                ${remaining.toFixed(0)}
              </p>
              <p className="text-[10px] text-[#6B7280]">remaining</p>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mt-3 h-3 w-full overflow-hidden rounded-full bg-[#374151]">
            <motion.div
              className="h-full rounded-full"
              style={{
                background: `linear-gradient(90deg, #10B981, #F59E0B ${Math.min(pct, 80)}%, #EF4444)`,
              }}
              initial={{ width: 0 }}
              animate={{ width: `${pct}%` }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
            />
          </div>

          {/* Threshold markers */}
          <div className="mt-1 flex justify-between text-[9px] text-[#6B7280]">
            <span>0%</span>
            <span>50%</span>
            <span>80%</span>
            <span>95%</span>
            <span>100%</span>
          </div>
        </div>

        {pct >= 80 && (
          <div className="mt-3 flex items-center gap-1.5 rounded bg-[#F59E0B]/10 p-2">
            <AlertTriangle className="h-3 w-3 text-[#F59E0B]" />
            <span className="text-[10px] text-[#F59E0B]">
              Approaching budget limit — consider denying non-critical approvals
            </span>
          </div>
        )}
      </GlassPanel>

      {/* Per-agent breakdown */}
      <GlassPanel>
        <h4 className="mb-3 text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
          Per-Agent Usage
        </h4>
        <div className="space-y-2.5">
          {Object.entries(budget.perAgentUsage).map(([agentId, usage]) => {
            const agentPct = (usage / Math.max(budget.currentUsage, 1)) * 100;
            const name = AGENT_NAMES[agentId] || agentId;
            const color = AGENT_COLORS[agentId] || '#9CA3AF';

            return (
              <div key={agentId}>
                <div className="mb-1 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: color }} />
                    <span className="text-[11px] text-[#F9FAFB]">{name}</span>
                  </div>
                  <span className="font-mono text-[10px] text-[#9CA3AF]">${usage.toFixed(0)}</span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#0A0E17]">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ backgroundColor: color }}
                    initial={{ width: 0 }}
                    animate={{ width: `${agentPct}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </GlassPanel>

      {/* Budget tips */}
      <GlassPanel>
        <div className="flex items-start gap-2">
          <PiggyBank className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#10B981]" />
          <div>
            <p className="text-[10px] font-semibold text-[#10B981]">Budget Tip</p>
            <p className="mt-0.5 text-[10px] leading-relaxed text-[#9CA3AF]">
              Deny high-risk external actions to preserve budget for critical operations.
            </p>
          </div>
        </div>
      </GlassPanel>
    </div>
  );
}
