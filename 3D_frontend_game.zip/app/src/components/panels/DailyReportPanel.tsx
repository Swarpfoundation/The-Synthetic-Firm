import { motion } from 'framer-motion';
import { useTsfStore } from '@/store/useTsfStore';
import { GlassPanel } from '@/components/ui/GlassPanel';
import {
  FileBarChart,
  CheckCircle,
  AlertTriangle,
  ShieldAlert,
  Lightbulb,
  ArrowRight,
  Play,
} from 'lucide-react';

export function DailyReportPanel() {
  const dailyReport = useTsfStore((s) => s.dailyReport);
  const isReportModalOpen = useTsfStore((s) => s.isReportModalOpen);
  const closeReportModal = useTsfStore((s) => s.closeReportModal);
  const startNewDay = useTsfStore((s) => s.startNewDay);
  const workdayClock = useTsfStore((s) => s.workdayClock);
  const tasks = useTsfStore((s) => s.tasks);
  const approvals = useTsfStore((s) => s.approvals);
  const budget = useTsfStore((s) => s.budget);

  // Use current stats if no report generated yet today
  const report = dailyReport || {
    day: workdayClock.day,
    date: new Date().toISOString().split('T')[0],
    completedTasks: tasks.filter((t) => t.status === 'completed').length,
    blockedTasks: tasks.filter((t) => t.status === 'blocked').length,
    pendingApprovals: approvals.filter((a) => a.status === 'pending').length,
    budgetUsage: budget.currentUsage,
    budgetLimit: budget.dailyLimit,
    sentinelRisks: approvals
      .filter((a) => a.riskLevel === 'high' || a.riskLevel === 'critical')
      .map((a) => `${a.requesterId}: ${a.action} (${a.riskLevel})`),
    founderQuestions: [
      `Review ${tasks.filter((t) => t.status === 'completed').length} completed tasks`,
      `Address ${tasks.filter((t) => t.status === 'blocked').length} blocked tasks`,
    ],
    nextActions: ['Continue monitoring', 'Review pending approvals'],
    efficiency: tasks.length > 0 ? Math.round((tasks.filter((t) => t.status === 'completed').length / tasks.length) * 100) : 100,
  };

  const handleContinue = () => {
    closeReportModal();
    startNewDay();
  };

  const efficiencyColor = report.efficiency >= 80 ? '#10B981' : report.efficiency >= 60 ? '#F59E0B' : '#EF4444';

  return (
    <div className="space-y-3">
      {/* Day header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileBarChart className="h-4 w-4 text-[#06B6D4]" />
          <span className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
            Day {report.day} Report
          </span>
        </div>
        <span className="font-mono text-[10px] text-[#6B7280]">{report.date}</span>
      </div>

      {/* Efficiency score */}
      <GlassPanel className="text-center">
        <p className="text-[10px] uppercase tracking-wider text-[#6B7280]">Operational Efficiency</p>
        <motion.p
          className="mt-1 font-mono text-4xl font-bold"
          style={{ color: efficiencyColor }}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 200 }}
        >
          {report.efficiency}%
        </motion.p>
        <div className="mx-auto mt-2 h-1.5 w-32 overflow-hidden rounded-full bg-[#374151]">
          <motion.div
            className="h-full rounded-full"
            style={{ backgroundColor: efficiencyColor }}
            initial={{ width: 0 }}
            animate={{ width: `${report.efficiency}%` }}
            transition={{ duration: 0.8 }}
          />
        </div>
      </GlassPanel>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-2">
        <GlassPanel className="text-center">
          <CheckCircle className="mx-auto h-4 w-4 text-[#10B981]" />
          <p className="mt-1 font-mono text-xl font-semibold text-[#F9FAFB]">{report.completedTasks}</p>
          <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Completed</p>
        </GlassPanel>
        <GlassPanel className="text-center">
          <AlertTriangle className="mx-auto h-4 w-4 text-[#F59E0B]" />
          <p className="mt-1 font-mono text-xl font-semibold text-[#F9FAFB]">{report.blockedTasks}</p>
          <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Blocked</p>
        </GlassPanel>
        <GlassPanel className="text-center">
          <ShieldAlert className="mx-auto h-4 w-4 text-[#F59E0B]" />
          <p className="mt-1 font-mono text-xl font-semibold text-[#F9FAFB]">{report.pendingApprovals}</p>
          <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Pending Approvals</p>
        </GlassPanel>
        <GlassPanel className="text-center">
          <div className="mx-auto flex h-4 w-4 items-center justify-center">
            <span className="font-mono text-[10px] text-[#06B6D4]">$</span>
          </div>
          <p className="mt-1 font-mono text-xl font-semibold text-[#F9FAFB]">
            ${report.budgetUsage.toFixed(0)}
          </p>
          <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">
            of ${report.budgetLimit}
          </p>
        </GlassPanel>
      </div>

      {/* Sentinel risks */}
      {report.sentinelRisks.length > 0 && (
        <GlassPanel>
          <h4 className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#EF4444]">
            <ShieldAlert className="h-3 w-3" />
            Sentinel Risk Flags
          </h4>
          <div className="space-y-1">
            {report.sentinelRisks.map((risk, i) => (
              <div key={i} className="rounded bg-[#EF4444]/5 p-1.5 text-[10px] text-[#F9FAFB]">
                {risk}
              </div>
            ))}
          </div>
        </GlassPanel>
      )}

      {/* Founder questions */}
      <GlassPanel>
        <h4 className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#F59E0B]">
          <Lightbulb className="h-3 w-3" />
          Action Items
        </h4>
        <div className="space-y-1">
          {report.founderQuestions.map((q, i) => (
            <div key={i} className="flex items-start gap-1.5">
              <ArrowRight className="mt-0.5 h-2.5 w-2.5 shrink-0 text-[#6B7280]" />
              <span className="text-[10px] text-[#9CA3AF]">{q}</span>
            </div>
          ))}
        </div>
      </GlassPanel>

      {/* Next actions */}
      <GlassPanel>
        <h4 className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#10B981]">
          <ArrowRight className="h-3 w-3" />
          Recommended Next Steps
        </h4>
        <div className="space-y-1">
          {report.nextActions.map((action, i) => (
            <div key={i} className="flex items-start gap-1.5">
              <span className="mt-0.5 flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full bg-[#10B981]/10 text-[8px] text-[#10B981]">
                {i + 1}
              </span>
              <span className="text-[10px] text-[#9CA3AF]">{action}</span>
            </div>
          ))}
        </div>
      </GlassPanel>

      {/* Start next day button (shown when report modal is open) */}
      {isReportModalOpen && (
        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={handleContinue}
          className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#06B6D4] py-3 text-xs font-semibold uppercase tracking-wider text-white transition-all hover:bg-[#06B6D4]/90"
        >
          <Play className="h-3.5 w-3.5" />
          Start Day {report.day + 1}
        </motion.button>
      )}
    </div>
  );
}
