import { motion } from 'framer-motion';
import { useTsfStore } from '@/store/useTsfStore';
import { formatTimestamp } from '@/utils/formatters';
import {
  ScrollText,
  CheckCircle,
  XCircle,
  AlertTriangle,
  MessageSquare,
  Users,
  Play,
  Pause,
  Square,
  FileText,
  Activity,
  ShieldAlert,
} from 'lucide-react';

const eventIcons: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  'task.created': FileText,
  'task.assigned': FileText,
  'task.started': Play,
  'task.blocked': AlertTriangle,
  'task.review_required': ShieldAlert,
  'task.completed': CheckCircle,
  'approval.requested': ShieldAlert,
  'approval.approved': CheckCircle,
  'approval.denied': XCircle,
  'message.sent': MessageSquare,
  'meeting.started': Users,
  'meeting.ended': Users,
  'budget.warning': AlertTriangle,
  'budget.exceeded': AlertTriangle,
  'runtime.paused': Pause,
  'runtime.resumed': Play,
  'runtime.killed': Square,
  'daily_report.generated': FileText,
  'agent.state_changed': Activity,
};

const eventColors: Record<string, string> = {
  'task.created': '#06B6D4',
  'task.assigned': '#06B6D4',
  'task.started': '#3B82F6',
  'task.blocked': '#EF4444',
  'task.review_required': '#EC4899',
  'task.completed': '#10B981',
  'approval.requested': '#F59E0B',
  'approval.approved': '#10B981',
  'approval.denied': '#EF4444',
  'message.sent': '#8B5CF6',
  'meeting.started': '#F9FAFB',
  'meeting.ended': '#9CA3AF',
  'budget.warning': '#F59E0B',
  'budget.exceeded': '#EF4444',
  'runtime.paused': '#F59E0B',
  'runtime.resumed': '#10B981',
  'runtime.killed': '#EF4444',
  'daily_report.generated': '#06B6D4',
  'agent.state_changed': '#8B5CF6',
};

export function EventTimeline() {
  const timeline = useTsfStore((s) => s.timeline);

  if (timeline.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-[#6B7280]">
        <ScrollText className="h-8 w-8 text-[#374151]" />
        <p className="mt-3 text-xs">No events yet</p>
        <p className="mt-1 text-[10px] text-[#4B5563]">Events will appear as the simulation runs</p>
      </div>
    );
  }

  return (
    <div className="space-y-0">
      {/* Event count */}
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
          Live Feed
        </span>
        <span className="font-mono text-[10px] text-[#6B7280]">{timeline.length} events</span>
      </div>

      {/* Timeline */}
      <div className="relative space-y-0">
        {/* Vertical line */}
        <div className="absolute left-[15px] top-0 bottom-0 w-px bg-[#1F2937]" />

        {timeline.map((event, index) => {
          const Icon = eventIcons[event.type] || Activity;
          const color = eventColors[event.type] || '#9CA3AF';
          const isRecent = index < 3;

          return (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.2, delay: index * 0.02 }}
              className={`relative flex gap-3 py-1.5 ${isRecent ? '' : 'opacity-60'}`}
            >
              {/* Icon dot */}
              <div
                className="relative z-10 flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-full"
                style={{
                  backgroundColor: `${color}15`,
                  border: `1.5px solid ${color}40`,
                }}
              >
                <Icon className="h-3 w-3" style={{ color } as React.CSSProperties} />
              </div>

              {/* Content */}
              <div className="min-w-0 flex-1 pt-0.5">
                <p className="truncate text-[11px] leading-tight text-[#F9FAFB]">
                  {event.message}
                </p>
                <div className="mt-0.5 flex items-center gap-2">
                  <span className="font-mono text-[9px] text-[#6B7280]">
                    {formatTimestamp(event.timestamp)}
                  </span>
                  <span
                    className="rounded px-1 py-0.5 text-[8px] font-medium uppercase tracking-wider"
                    style={{
                      backgroundColor: `${color}15`,
                      color: color,
                    }}
                  >
                    {event.type.split('.')[0]}
                  </span>
                  {event.agentId && (
                    <span className="text-[9px] text-[#6B7280]">{event.agentId}</span>
                  )}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
