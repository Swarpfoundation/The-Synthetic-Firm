import { motion, AnimatePresence } from 'framer-motion';
import { useTsfStore } from '@/store/useTsfStore';
import { AgentInspector } from './AgentInspector';
import { TaskBoard } from './TaskBoard';
import { ApprovalInbox } from './ApprovalInbox';
import { BudgetPanel } from './BudgetPanel';
import { DailyReportPanel } from './DailyReportPanel';
import { EventTimeline } from './EventTimeline';
import {
  Users,
  ClipboardList,
  ShieldAlert,
  Wallet,
  FileBarChart,
  ScrollText,
} from 'lucide-react';

const tabs = [
  { id: 'agents', label: 'Agents', icon: Users },
  { id: 'tasks', label: 'Tasks', icon: ClipboardList },
  { id: 'approvals', label: 'Approvals', icon: ShieldAlert },
  { id: 'budget', label: 'Budget', icon: Wallet },
  { id: 'reports', label: 'Reports', icon: FileBarChart },
  { id: 'events', label: 'Event Log', icon: ScrollText },
];

export function FounderControlPanel() {
  const activePanelTab = useTsfStore((s) => s.activePanelTab);
  const setActivePanelTab = useTsfStore((s) => s.setActivePanelTab);
  const approvals = useTsfStore((s) => s.approvals);
  const pendingCount = approvals.filter((a) => a.status === 'pending').length;

  return (
    <div className="flex h-full w-[380px] shrink-0 flex-col border-l border-[#1F2937] bg-[#111827]">
      {/* Tabs */}
      <div className="flex border-b border-[#1F2937]">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activePanelTab === tab.id;
          const showBadge = tab.id === 'approvals' && pendingCount > 0;

          return (
            <button
              key={tab.id}
              onClick={() => setActivePanelTab(tab.id)}
              className="relative flex flex-1 flex-col items-center gap-0.5 py-2.5 transition-all"
            >
              <div className="relative">
                <Icon
                  className="h-4 w-4"
                  style={{ color: isActive ? '#06B6D4' : '#6B7280' }}
                />
                {showBadge && (
                  <span className="absolute -right-2 -top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[#EF4444] text-[8px] font-bold text-white">
                    {pendingCount}
                  </span>
                )}
              </div>
              <span
                className="text-[9px] font-medium uppercase tracking-wider"
                style={{ color: isActive ? '#06B6D4' : '#6B7280' }}
              >
                {tab.label}
              </span>
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#06B6D4]"
                  transition={{ duration: 0.2 }}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-3">
        <AnimatePresence mode="wait">
          <motion.div
            key={activePanelTab}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.15 }}
          >
            {activePanelTab === 'agents' && <AgentInspector />}
            {activePanelTab === 'tasks' && <TaskBoard />}
            {activePanelTab === 'approvals' && <ApprovalInbox />}
            {activePanelTab === 'budget' && <BudgetPanel />}
            {activePanelTab === 'reports' && <DailyReportPanel />}
            {activePanelTab === 'events' && <EventTimeline />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
