import { motion, AnimatePresence } from 'framer-motion';
import { useTsfStore } from '@/store/useTsfStore';
import { DailyReportPanel } from './DailyReportPanel';
import { X } from 'lucide-react';

export function ReportModal() {
  const isReportModalOpen = useTsfStore((s) => s.isReportModalOpen);
  const closeReportModal = useTsfStore((s) => s.closeReportModal);

  return (
    <AnimatePresence>
      {isReportModalOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{
            backgroundColor: 'rgba(10, 14, 23, 0.9)',
            backdropFilter: 'blur(8px)',
          }}
          onClick={closeReportModal}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="relative max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-xl border border-[#374151] bg-[#111827] p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close button */}
            <button
              onClick={closeReportModal}
              className="absolute right-4 top-4 flex h-7 w-7 items-center justify-center rounded-full bg-[#1F2937] text-[#6B7280] transition-all hover:bg-[#374151] hover:text-[#F9FAFB]"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Header */}
            <div className="mb-4">
              <h2 className="text-xl font-bold tracking-wider text-[#F9FAFB]">
                DAILY REPORT
              </h2>
              <p className="mt-1 text-xs text-[#6B7280]">
                End of day summary — review before continuing
              </p>
            </div>

            {/* Report content */}
            <DailyReportPanel />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
