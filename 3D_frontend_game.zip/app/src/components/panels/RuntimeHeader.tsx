import { motion } from 'framer-motion';
import { useTsfStore } from '@/store/useTsfStore';
import { getPhaseLabel, formatTimeUntilEnd } from '@/utils/workday';
import {
  Play,
  Pause,
  Square,
  Activity,
  Clock,
  Zap,
} from 'lucide-react';

export function RuntimeHeader() {
  const runtimeState = useTsfStore((s) => s.runtimeState);
  const workdayClock = useTsfStore((s) => s.workdayClock);
  const budget = useTsfStore((s) => s.budget);
  const pauseRuntime = useTsfStore((s) => s.pauseRuntime);
  const resumeRuntime = useTsfStore((s) => s.resumeRuntime);
  const killRuntime = useTsfStore((s) => s.killRuntime);

  const budgetPct = (budget.currentUsage / budget.dailyLimit) * 100;
  const budgetColor = budgetPct >= 95 ? '#EF4444' : budgetPct >= 80 ? '#F59E0B' : budgetPct >= 50 ? '#F59E0B' : '#10B981';

  return (
    <header className="flex h-[60px] items-center justify-between border-b border-[#1F2937] bg-[#111827] px-4">
      {/* Left: Logo */}
      <div className="flex items-center gap-3">
        <div className="flex h-8 w-8 items-center justify-center rounded bg-[#06B6D4]/10">
          <Activity className="h-4 w-4 text-[#06B6D4]" />
        </div>
        <div>
          <h1 className="text-sm font-bold tracking-[0.15em] text-[#F9FAFB]">
            TSF CONTROL ROOM
          </h1>
          <p className="text-[10px] tracking-wider text-[#6B7280]">
            DAY {workdayClock.day} — SYNTHETIC FIRM
          </p>
        </div>
      </div>

      {/* Center: Clock & Phase */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-[#06B6D4]" />
          <span className="font-mono text-lg font-semibold text-[#F9FAFB]">
            {workdayClock.currentTime}
          </span>
          <span className="text-[10px] text-[#6B7280]">CET</span>
        </div>

        <div className="h-6 w-px bg-[#374151]" />

        <div className="flex items-center gap-2">
          <motion.div
            className="h-2 w-2 rounded-full"
            style={{ backgroundColor: workdayClock.isWithinWorkHours ? '#10B981' : '#6B7280' }}
            animate={{ opacity: [1, 0.5, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <span
            className="rounded px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider"
            style={{
              backgroundColor: `${getStatusColor(workdayClock.phase)}20`,
              color: getStatusColor(workdayClock.phase),
              border: `1px solid ${getStatusColor(workdayClock.phase)}40`,
            }}
          >
            {getPhaseLabel(workdayClock.phase)}
          </span>
        </div>

        <div className="h-6 w-px bg-[#374151]" />

        <span className="text-[10px] text-[#6B7280]">
          {formatTimeUntilEnd(workdayClock.currentTime)}
        </span>
      </div>

      {/* Right: Budget + Controls */}
      <div className="flex items-center gap-4">
        {/* Budget mini-meter */}
        <div className="flex items-center gap-2">
          <Zap className="h-3.5 w-3.5" style={{ color: budgetColor }} />
          <div className="w-24">
            <div className="mb-1 flex justify-between">
              <span className="text-[9px] uppercase tracking-wider text-[#6B7280]">Budget</span>
              <span className="font-mono text-[9px]" style={{ color: budgetColor }}>
                {Math.round(budgetPct)}%
              </span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#374151]">
              <motion.div
                className="h-full rounded-full"
                style={{ backgroundColor: budgetColor }}
                animate={{ width: `${Math.min(budgetPct, 100)}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>
        </div>

        <div className="h-6 w-px bg-[#374151]" />

        {/* Runtime controls */}
        <div className="flex items-center gap-1.5">
          {/* Active indicator */}
          <div
            className="flex h-7 items-center gap-1.5 rounded px-2.5 text-[10px] font-semibold uppercase tracking-wider"
            style={{
              backgroundColor: runtimeState === 'active' ? '#10B98120' : runtimeState === 'paused' ? '#F59E0B20' : '#EF444420',
              color: runtimeState === 'active' ? '#10B981' : runtimeState === 'paused' ? '#F59E0B' : '#EF4444',
              border: `1px solid ${runtimeState === 'active' ? '#10B98140' : runtimeState === 'paused' ? '#F59E0B40' : '#EF444440'}`,
            }}
          >
            <div
              className="h-1.5 w-1.5 rounded-full"
              style={{
                backgroundColor: runtimeState === 'active' ? '#10B981' : runtimeState === 'paused' ? '#F59E0B' : '#EF4444',
              }}
            />
            {runtimeState}
          </div>

          {runtimeState === 'active' ? (
            <button
              onClick={pauseRuntime}
              className="flex h-7 w-7 items-center justify-center rounded bg-[#F59E0B]/10 text-[#F59E0B] transition-all hover:bg-[#F59E0B]/20"
              title="Pause"
            >
              <Pause className="h-3.5 w-3.5" />
            </button>
          ) : runtimeState === 'paused' ? (
            <button
              onClick={resumeRuntime}
              className="flex h-7 w-7 items-center justify-center rounded bg-[#10B981]/10 text-[#10B981] transition-all hover:bg-[#10B981]/20"
              title="Resume"
            >
              <Play className="h-3.5 w-3.5" />
            </button>
          ) : null}

          <button
            onClick={killRuntime}
            disabled={runtimeState === 'killed'}
            className="flex h-7 w-7 items-center justify-center rounded bg-[#EF4444]/10 text-[#EF4444] transition-all hover:bg-[#EF4444]/20 disabled:opacity-30"
            title="Kill"
          >
            <Square className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
}

function getStatusColor(phase: string): string {
  const colors: Record<string, string> = {
    planning: '#06B6D4',
    execution: '#10B981',
    review: '#8B5CF6',
    report: '#F59E0B',
    closed: '#6B7280',
  };
  return colors[phase] || '#9CA3AF';
}
