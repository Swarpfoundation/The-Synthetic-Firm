import { motion, AnimatePresence } from 'framer-motion';
import { useTsfStore } from '@/store/useTsfStore';
import { GlassPanel } from '@/components/ui/GlassPanel';
import { StatusPill } from '@/components/ui/StatusPill';
import { ClipboardList, AlertTriangle } from 'lucide-react';

const columns: { id: string; label: string; color: string }[] = [
  { id: 'proposed', label: 'Proposed', color: '#6B7280' },
  { id: 'in_progress', label: 'In Progress', color: '#3B82F6' },
  { id: 'review_required', label: 'Review', color: '#EC4899' },
  { id: 'approval_required', label: 'Approval', color: '#F59E0B' },
  { id: 'completed', label: 'Completed', color: '#10B981' },
  { id: 'blocked', label: 'Blocked', color: '#EF4444' },
];

export function TaskBoard() {
  const tasks = useTsfStore((s) => s.tasks);

  if (tasks.length === 0) {
    return (
      <GlassPanel className="flex flex-col items-center justify-center py-12">
        <ClipboardList className="h-8 w-8 text-[#374151]" />
        <p className="mt-3 text-xs text-[#6B7280]">No tasks yet</p>
        <p className="mt-1 text-[10px] text-[#4B5563]">Waiting for event simulation...</p>
      </GlassPanel>
    );
  }

  return (
    <div className="space-y-3">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded bg-[#0A0E17] p-2 text-center">
          <p className="font-mono text-lg font-semibold text-[#F9FAFB]">{tasks.length}</p>
          <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Total</p>
        </div>
        <div className="rounded bg-[#0A0E17] p-2 text-center">
          <p className="font-mono text-lg font-semibold text-[#10B981]">
            {tasks.filter((t) => t.status === 'completed').length}
          </p>
          <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Done</p>
        </div>
        <div className="rounded bg-[#0A0E17] p-2 text-center">
          <p className="font-mono text-lg font-semibold text-[#EF4444]">
            {tasks.filter((t) => t.status === 'blocked').length}
          </p>
          <p className="text-[9px] uppercase tracking-wider text-[#6B7280]">Blocked</p>
        </div>
      </div>

      {/* Task columns */}
      {columns.map((col) => {
        const colTasks = tasks.filter((t) => t.status === col.id);
        if (colTasks.length === 0) return null;

        return (
          <div key={col.id}>
            <div className="mb-1.5 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <div className="h-2 w-2 rounded-full" style={{ backgroundColor: col.color }} />
                <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: col.color }}>
                  {col.label}
                </span>
              </div>
              <span className="font-mono text-[10px] text-[#6B7280]">{colTasks.length}</span>
            </div>

            <div className="space-y-1.5">
              <AnimatePresence>
                {colTasks.map((task) => (
                  <motion.div
                    key={task.id}
                    layout
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.2 }}
                  >
                    <GlassPanel className="py-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[11px] text-[#F9FAFB]">{task.title}</p>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="text-[9px] text-[#6B7280]">
                              {task.assignedTo || 'unassigned'}
                            </span>
                            {task.priority === 'high' && (
                              <span className="flex items-center gap-0.5 text-[9px] text-[#EF4444]">
                                <AlertTriangle className="h-2.5 w-2.5" /> High
                              </span>
                            )}
                          </div>
                        </div>
                        <StatusPill status={task.status} size="sm" />
                      </div>
                      {task.estimatedCost > 0 && (
                        <div className="mt-1.5 flex items-center justify-between border-t border-[#1F2937] pt-1.5">
                          <span className="text-[9px] text-[#6B7280]">Est. Cost</span>
                          <span className="font-mono text-[9px] text-[#F9FAFB]">${task.estimatedCost}</span>
                        </div>
                      )}
                    </GlassPanel>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        );
      })}
    </div>
  );
}
