import { create } from 'zustand';
import type { AgentId, RuntimeState, TsfState } from '@/types/tsf';
import { initialState } from '@/mocks/tsf-state';
import { createEventStream, type GeneratedEvent } from '@/mocks/tsf-events';
import {
  processEvent,
  approveApproval,
  denyApproval,
  setRuntimeState,
  advanceClock,
  startNewDay,
} from '@/utils/eventReducer';

// ============================================
// Zustand Store for TSF State Management
// ============================================

interface TsfActions {
  // Event simulation
  startEventSimulation: () => void;
  stopEventSimulation: () => void;
  processGeneratedEvent: (event: GeneratedEvent) => void;

  // Runtime controls
  setRuntimeState: (state: RuntimeState) => void;
  pauseRuntime: () => void;
  resumeRuntime: () => void;
  killRuntime: () => void;

  // Clock
  advanceClock: () => void;
  startNewDay: () => void;

  // Selection
  selectAgent: (agentId: AgentId | null) => void;
  selectRoom: (roomId: string | null) => void;
  setActivePanelTab: (tab: string) => void;

  // Approvals
  approveRequest: (approvalId: string) => void;
  denyRequest: (approvalId: string) => void;

  // Report
  openReportModal: () => void;
  closeReportModal: () => void;

  // Reset
  resetStore: () => void;
}

let eventStreamInstance: ReturnType<typeof createEventStream> | null = null;

export const useTsfStore = create<TsfState & TsfActions>((set, get) => ({
  ...initialState,

  // Event simulation
  startEventSimulation: () => {
    if (eventStreamInstance) {
      eventStreamInstance.stop();
    }
    eventStreamInstance = createEventStream((event) => {
      const state = get();
      if (state.runtimeState !== 'active') return;
      get().processGeneratedEvent(event);
    });
    eventStreamInstance.start(4000);
    set({ eventSimulationActive: true });
  },

  stopEventSimulation: () => {
    if (eventStreamInstance) {
      eventStreamInstance.stop();
    }
    set({ eventSimulationActive: false });
  },

  processGeneratedEvent: (event) => {
    const state = get();
    if (state.runtimeState !== 'active') return;
    const updates = processEvent(state, event);
    set(updates);
  },

  // Runtime controls
  setRuntimeState: (newState) => {
    const state = get();
    const updates = setRuntimeState(state, newState);
    set(updates);
  },

  pauseRuntime: () => {
    const state = get();
    const updates = setRuntimeState(state, 'paused');
    set(updates);
    if (eventStreamInstance) eventStreamInstance.stop();
  },

  resumeRuntime: () => {
    const state = get();
    const updates = setRuntimeState(state, 'active');
    set(updates);
    if (eventStreamInstance) eventStreamInstance.start(4000);
  },

  killRuntime: () => {
    const state = get();
    const updates = setRuntimeState(state, 'killed');
    set(updates);
    if (eventStreamInstance) eventStreamInstance.stop();
  },

  // Clock
  advanceClock: () => {
    const state = get();
    const updates = advanceClock(state);
    set(updates);
  },

  startNewDay: () => {
    const state = get();
    const updates = startNewDay(state);
    set(updates);
  },

  // Selection
  selectAgent: (agentId) => {
    set({ selectedAgentId: agentId, selectedRoomId: null });
    if (agentId) {
      set({ activePanelTab: 'agents' });
    }
  },

  selectRoom: (roomId) => {
    set({ selectedRoomId: roomId, selectedAgentId: null });
    if (roomId) {
      set({ activePanelTab: 'agents' });
    }
  },

  setActivePanelTab: (tab) => set({ activePanelTab: tab }),

  // Approvals
  approveRequest: (approvalId) => {
    const state = get();
    const updates = approveApproval(state, approvalId);
    set(updates);
  },

  denyRequest: (approvalId) => {
    const state = get();
    const updates = denyApproval(state, approvalId);
    set(updates);
  },

  // Report
  openReportModal: () => set({ isReportModalOpen: true }),
  closeReportModal: () => set({ isReportModalOpen: false }),

  // Reset
  resetStore: () => {
    if (eventStreamInstance) {
      eventStreamInstance.stop();
      eventStreamInstance = null;
    }
    set(initialState);
  },
}));
