// ============================================
// Workday Clock Utilities
// ============================================

export function addMinutes(time: string, minutes: number): string {
  const [h, m] = time.split(':').map(Number);
  const totalMinutes = h * 60 + m + minutes;
  const newH = Math.floor(totalMinutes / 60);
  const newM = totalMinutes % 60;
  return `${String(newH).padStart(2, '0')}:${String(newM).padStart(2, '0')}`;
}

export function isWithinWorkHours(time: string): boolean {
  return time >= '09:00' && time <= '17:00';
}

export function getWorkdayPhase(time: string): 'planning' | 'execution' | 'review' | 'report' | 'closed' {
  if (time < '09:00') return 'closed';
  if (time < '10:00') return 'planning';
  if (time < '16:00') return 'execution';
  if (time < '17:00') return 'review';
  return 'report';
}

export function getPhaseLabel(phase: string): string {
  const labels: Record<string, string> = {
    planning: 'PLANNING',
    execution: 'EXECUTION',
    review: 'REVIEW',
    report: 'REPORT',
    closed: 'CLOSED',
  };
  return labels[phase] || phase.toUpperCase();
}

export function formatTimeUntilEnd(time: string): string {
  const [h, m] = time.split(':').map(Number);
  const endH = 17;
  const endM = 0;
  const currentMinutes = h * 60 + m;
  const endMinutes = endH * 60 + endM;
  const diff = Math.max(0, endMinutes - currentMinutes);
  const diffH = Math.floor(diff / 60);
  const diffM = diff % 60;
  return `${diffH}h ${diffM}m remaining`;
}
